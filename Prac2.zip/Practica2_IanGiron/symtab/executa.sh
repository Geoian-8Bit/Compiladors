#!/bin/bash

#GEI - Compiladors Pràctica 1
#Autor: David Ferrer Fernández


if [ $# -lt 1 ]; then
	echo "ERROR: És necessari 1 paràmetre pel fitxer d'entrada"
	exit 1
fi

# Declaracion de variables
output=""
debug=""
fitxer=""
bison=*.y
flex=*.l
warnings='none'

# Esta funcion borra todos los ficheros generados en el proceso de compilacion
function esborra {
	$(rm --force *.tab.? *.out *.yy.c *.output)
}

# Esta funcion genera el compilador mediante flex y bison, y ejecuta el compilador
function executa {
    # Borro todo
	esborra

	# Compilo todo
	$(bison --warnings=$warnings $debug -dv $bison && flex $flex && cc *.tab.c symtab/symtab.c funcions.c lex.yy.c -lm)

	# Ejecuto
	./a.out $fitxer > $(echo $fitxer | cut -d '.' -f1)"_out.txt"
	cat $(echo $fitxer | cut -d '.' -f1)"_out.txt"
}

for param in "$@"; do
	# Parametro para mostrar la ayuda
	if [ "$param" = "--help" ] || [ "$param" = "-h" ]; then
		more README.txt
		exit 0
	fi

	# Parametro para habilitar los warnings
	if [ "$param" = "--warnings" ] || [ "$param" = "-w" ]; then
		warnings='all'
	fi

	# Parametro para elegir fichero bison .y 
	if [ "$param" = "--bison" ] || [ "$param" = "-b" ]; then
		bison=""
	else
		if [ "$bison" = "" ]; then
			if [ -f $param ] && [ "$param" = *.y ]; then
		 			bison=$param
		 	else
		 		echo "ERROR: No sha trobat el fitxer bison .y"
		 		exit 1
		 	fi
		fi
	fi

	# Parametro para elegir fichero flex .l 
	if [ "$param" = "--flex" ] || [ "$param" = "-f" ]; then
		flex=""
	else
		if [ "$flex" = "" ]; then
			if [ -f $param ] && [ "$param" = *.l ]; then
		 			flex=$param
		 	else
		 		echo "ERROR: No sha trobat el fitxer flex .l"
		 		exit 1
		 	fi
		fi
	fi
	
	# Parametro para eliminar ficheros
	if [ "$param" = "--clean" ] || [ "$param" = "-c" ]; then
 		esborra
 		exit 0
 	fi

 	# Parametro para debugar
 	if [ "$param" = "--debug" ] || [ "$param" = "-t" ]; then
 		debug=$param
 	fi

 	# Parametro fichero entrada para el compilador
 	if [ -f $param ]; then
 		if [ "$param" != *.y ] && [ "$param" != *.l ]; then
 			fitxer=$param
 		fi
 	fi
done

# Compruebo que se haya introducido un fichero de entrada para el compilador
if [ "$fitxer" = "" ]; then
	echo "ERROR: fitxer d'entrada no trobat"
	exit 1
fi

if [ "$flex" = "" ]; then
	echo "ERROR: No sha trobat el fitxer flex .l"
	exit 1
fi

if [ "$bison" = "" ]; then
	echo "ERROR: No sha trobat el fitxer bison .y"
	exit 1
fi

#Inicio el proceso de compilacion
executa
exit 0
