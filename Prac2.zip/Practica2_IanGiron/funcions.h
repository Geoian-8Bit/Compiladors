#ifndef EXEMPLE_FUNCIONS_H
#define EXEMPLE_FUNCIONS_H
#include "dades.h"


char * print_func(value_info id);
char * print_func2(value_info id);
char * print_type(value_info id);
int ch_oct_int(char * oct);
int ch_hex_int(char * hex);
char* ch_int_hex (int decimalNumber);
char* ch_int_oct (int decimalNumber);

char* num_lin();
value_info print_do();
void print_final(value_info id, char * exp);
void print_assign_array(value_info id, value_info exp, value_info exp2);
value_info print_array(value_info id, value_info exp);

value_info or_func(value_info id1, value_info id2);
value_info and_func(value_info id1, value_info id2);
value_info not_func(value_info id1);
value_info gt_func(value_info id1, value_info id2);
value_info ge_func(value_info id1, value_info id2);
value_info lt_func(value_info id1, value_info id2);
value_info le_func(value_info id1, value_info id2);
value_info eq_func(value_info id1, value_info id2);
value_info ne_func(value_info id1, value_info id2);

value_info add(value_info id1, value_info id2);
value_info sub(value_info id1, value_info id2);
value_info mul(value_info id1, value_info id2);
value_info div_a(value_info id1, value_info id2);
value_info mod_a(value_info id1, value_info id2);
value_info pow_a(value_info id1, value_info id2);
value_info ch_sign(value_info id1);

value_info sin_a(value_info id1);
value_info cos_a(value_info id1);
value_info tan_a(value_info id1);
value_info str(value_info id1);

float sin_func(float id1);
float factorial(int n);
float calcularSeno(float grados);
float calcularCoseno(float grados);
float calcularTangente(float grados);

float mod_func(float id1, int id2);
value_info pow_func(value_info id1, value_info id2);
int init_analisi_lexica(char *);
int end_analisi_lexica();

int init_analisi_sintactica(char *);
int end_analisi_sintactica(void);

int analisi_semantica(void);

void yyerror(char *explanation);



#endif
