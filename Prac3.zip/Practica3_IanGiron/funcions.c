#include <stdio.h>
#include <stdlib.h>
#include "dades.h"
#include "funcions.h"
#include <string.h>
#include <math.h>
#include "./symtab/symtab.h"

extern int yyparse();
extern FILE *yyin;
extern FILE *yyout;
extern int yylineno;

void print_code(char* code){
	extern C3A varc3a;
	varc3a.code[varc3a.num-1] = strdup(code);
	varc3a.num++;
}

int ch_oct_int(char * oct){
    int length = strlen(oct);
    int decimalNumber = 0;
    int base = 1; // Inicializamos la base en 1 para el cálculo

    for (int i = length - 1; i >= 0; i--) {
        // Convertimos cada dígito de la cadena en su equivalente decimal
        int digit = oct[i] - '0';
        
        // Multiplicamos el dígito por la base y lo sumamos al número decimal
        decimalNumber += digit * base;
        
        // Actualizamos la base multiplicando por 8 (base octal)
        base *= 8;
    }
    return decimalNumber;
}
int ch_hex_int(char * hex){
    int length = strlen(hex);
    int decimalNumber = 0;
    int base = 1; // Inicializamos la base en 1 para el cálculo

    for (int i = length - 1; i >= 0; i--) {
        // Convertimos cada dígito de la cadena en su equivalente decimal
        int digit;
        if (hex[i] >= '0' && hex[i] <= '9') {
            digit = hex[i] - '0';
        } else if (hex[i] >= 'A' && hex[i] <= 'F') {
            digit = hex[i] - 'A' + 10; // A-F tienen valores de 10 a 15 en hexadecimal
        } else if (hex[i] >= 'a' && hex[i] <= 'f') {
            digit = hex[i] - 'a' + 10; // a-f tienen valores de 10 a 15 en hexadecimal
        } else {
            // Caracter inválido en formato hexadecimal
            printf("Caracter inválido: %c\n", hex[i]);
            return -1; // Valor de retorno para indicar un error
        }
        
        // Multiplicamos el dígito por la base y lo sumamos al número decimal
        decimalNumber += digit * base;
        
        // Actualizamos la base multiplicando por 16 (base hexadecimal)
        base *= 16;
    }

    return decimalNumber;

}

char* ch_int_hex (int decimalNumber){
    char* hexNumber = (char*)malloc(20 * sizeof(char));
    
    if (hexNumber == NULL) {
        printf("Error al asignar memoria.\n");
        return NULL;
    }

    int index = 0;

    // Mientras el número decimal no sea cero
    while (decimalNumber != 0) {
        int remainder = decimalNumber % 16;
        char hexDigit;

        // Convertir el residuo a su equivalente hexadecimal
        if (remainder < 10) {
            hexDigit = remainder + '0';
        } else {
            hexDigit = remainder - 10 + 'A';
        }

        // Almacenar el dígito hexadecimal en el buffer
        hexNumber[index++] = hexDigit;

        // Dividir el número decimal por 16 para continuar con la conversión
        decimalNumber /= 16;
    }

    // Si el número inicial era cero, se añade '0' al string hexadecimal
    if (index == 0) {
        hexNumber[index++] = '0';
    }

    // Agregar el terminador nulo al final de la cadena
    hexNumber[index] = '\0';

    // Invertir el string hexadecimal, ya que se construyó al revés
    int i, j;
    char temp;
    for (i = 0, j = index - 1; i < j; i++, j--) {
        temp = hexNumber[i];
        hexNumber[i] = hexNumber[j];
        hexNumber[j] = temp;
    }

    return hexNumber;
}

char* ch_int_oct (int decimalNumber){
    char* octalNumber = (char*)malloc(20 * sizeof(char));
    
    if (octalNumber == NULL) {
        printf("Error al asignar memoria.\n");
        return NULL;
    }

    int index = 0;

    // Mientras el número decimal no sea cero
    while (decimalNumber != 0) {
        int remainder = decimalNumber % 8;

        // Almacenar el dígito octal en el buffer
        octalNumber[index++] = remainder + '0';

        // Dividir el número decimal por 8 para continuar con la conversión
        decimalNumber /= 8;
    }

    // Si el número inicial era cero, se añade '0' al string octal
    if (index == 0) {
        octalNumber[index++] = '0';
    }

    // Agregar el terminador nulo al final de la cadena
    octalNumber[index] = '\0';

    // Invertir el string octal, ya que se construyó al revés
    int i, j;
    char temp;
    for (i = 0, j = index - 1; i < j; i++, j--) {
        temp = octalNumber[i];
        octalNumber[i] = octalNumber[j];
        octalNumber[j] = temp;
    }

    return octalNumber;
}

line* addList(){
	extern C3A varc3a;
	line l;
	line* line;
	l.linenum = varc3a.num-2;
	l.nextLine = NULL;
	line = malloc(sizeof(line));
	line[0] = l;
	return line;
}
line* addList2(){
	extern C3A varc3a;
	line l;
	line* line;
	l.linenum = varc3a.num-1;
	l.nextLine = NULL;
	line = malloc(sizeof(line));
	line[0] = l;
	return line;
}

line* unionList(line* list1, line* list2){
	line* res;
	res = list2;
	if(list1 != NULL){
		res = list1;
		while(list1->nextLine != NULL) list1 = list1->nextLine;
		list1->nextLine = list2;
	}
	return res;
}

void addGoto(line* list, int num){
	extern C3A varc3a;
  	char* aux;
  	char temp[50];
  	
	while(list != NULL){
		aux = varc3a.code[list->linenum];
		
		num = num;
		sprintf(temp,"%i", num);
		strcat(aux, temp);
		strcat(aux, "\n");
		varc3a.code[list->linenum] = aux;
		list = list->nextLine;
	}
}

void if_func(value_info id){
	extern C3A varc3a;
	
	if(id.val_type != BOOLEAN_TYPE ){
		yylineno--;
		yyerror("Semantical error: condition not is Boolean");
	}else{
		addGoto(id.truelist, id.val_int);
		addGoto(id.falselist, varc3a.num);
	}
	
}
void else_func(value_info id, value_info id2){
	extern C3A varc3a;
	char* aux;
	char temp[50];
	
	if(id2.val_type != BOOLEAN_TYPE ){
		yylineno--;
		yyerror("Semantical error: condition not is Boolean");
	}else{
		addGoto(id2.truelist, id2.val_int);
		addGoto(id2.falselist, id.boolean+1);
		
		aux = varc3a.code[id.hex_oct-2];
		sprintf(temp,"%i", varc3a.num);
		strcat(aux, temp);
		strcat(aux, "\n");
		varc3a.code[id.hex_oct-2] = aux;
	}

}
int else_print(){
	extern C3A varc3a;
	char *result_string = (char *)malloc(100 * sizeof(char)); // Asumiendo un tamaño suficientemente grande
   	strcpy(result_string, "");
    	char temp[50];
    	
	sprintf(temp, "%i", varc3a.num);
	strcpy(result_string, temp);
	strcat(result_string, ": GOTO ");
	print_code(result_string);
	return varc3a.num;
}

void while_func(value_info id, value_info id2){
	extern C3A varc3a;
	char *result_string = (char *)malloc(100 * sizeof(char)); // Asumiendo un tamaño suficientemente grande
   	strcpy(result_string, "");
    	char temp[50];
    	
    	if(id2.val_type != BOOLEAN_TYPE ){
		yylineno--;
		yyerror("Semantical error: condition not is Boolean");
	}else{
		addGoto(id2.truelist, id2.val_int);
		addGoto(id2.falselist, varc3a.num+1);
		
		sprintf(temp, "%i", varc3a.num);
		strcpy(result_string, temp);
		strcat(result_string, ": GOTO ");
		sprintf(temp, "%i", id.val_int);
		strcat(result_string, temp);
		strcat(result_string, "\n");
		print_code(result_string);
	}
}

void until_func(value_info id, value_info id2){
	extern C3A varc3a;
    	
	if(id.val_type != BOOLEAN_TYPE ){
		yylineno--;
		yyerror("Semantical error: condition not is Boolean");
	}else{
		addGoto(id.truelist, id2.val_int);
		addGoto(id.falselist, varc3a.num);
		
	}
}

void for_func(value_info id, value_info id2, value_info id3){
	extern C3A varc3a;
	int i = 0;
	if(id.val_type != INT_TYPE){
		yylineno--;
		yyerror("Semantical error: id not is Int or Float");
	}else if (id2.val_type != INT_TYPE){
		yylineno--;
		yyerror("Semantical error: rang1 not isInt or Float");
	}else if (id3.val_type != INT_TYPE){
		yylineno--;
		yyerror("Semantical error: rang2 not is Int or Float");
	}else{
		if (id2.val_type == INT_TYPE && id3.val_type == INT_TYPE){
			if(id2.val_int > id3.val_int){
				i = 1;
			}
		}
		if(i == 1){
			yylineno--;
			yyerror("Semantical error: for not is executed");
		}
	}
}
void final_for_func(value_info id, value_info id2, value_info id3, value_info id4){
	extern C3A varc3a;
	value_info aux;
	char *result_string = (char *)malloc(100 * sizeof(char)); // Asumiendo un tamaño suficientemente grande
   	strcpy(result_string, "");
    	char temp[50];
	
	sprintf(temp, "%i", varc3a.num);
	strcat(result_string, temp);
	strcat(result_string, ": ");
	strcat(result_string, id.name);
	strcat(result_string, " := ");
	strcat(result_string, id.name);
	strcat(result_string, " ADDI 1");
	strcat(result_string, "\n");
			    	
	print_code(result_string);
	
	aux = ge_func(id, id2);
	addGoto(aux.truelist, varc3a.num);
	addGoto(aux.falselist, varc3a.num+2);
	
	aux = lt_func(id, id3);
	addGoto(aux.truelist, id4.val_int);
	addGoto(aux.falselist, varc3a.num);
	
}

value_info case_func (value_info id){
	extern C3A varc3a;
	value_info aux;
	char *result_string = (char *)malloc(100 * sizeof(char)); // Asumiendo un tamaño suficientemente grande
   	strcpy(result_string, "");
    	char temp[50];
    	
	strcat(result_string, id.name);
	strcat(result_string, " GOTO ");
	sprintf(temp, "%i", varc3a.num+2);
	strcat(result_string, temp);
	strcat(result_string, "\n");
	aux.truelist = addList2();
	
	print_code(result_string);
	
	
	sprintf(temp, "%i", varc3a.num);
	strcpy(result_string, temp);
	strcat(result_string, ": GOTO ");
	aux.falselist = addList2();
	    	
	print_code(result_string);
	
	return aux;
}

void swapNodes(line *a, line *b) {
    int temp = a->linenum;
    a->linenum = b->linenum;
    b->linenum = temp;
}

void bubbleSort(line *start) {
    int swapped;
    line *ptr1;
    line *lptr = NULL;

    // Verifica si la lista está vacía
    if (start == NULL)
        return;

    do {
        swapped = 0;
        ptr1 = start;

        while (ptr1->nextLine != lptr) {
            if (ptr1->linenum > ((line *)(ptr1->nextLine))->linenum) {
                swapNodes(ptr1, (line *)(ptr1->nextLine));
                swapped = 1;
            }
            ptr1 = (line *)(ptr1->nextLine);
        }
        lptr = ptr1;
    } while (swapped);
}

void switch_func(value_info id, value_info id2){
	extern C3A varc3a;
  	char* aux;
  	char *result_string = (char *)malloc(100 * sizeof(char)); 
  	char temp[50];
  	int num;
  	
  	bubbleSort(id2.falselist);
  	bubbleSort(id2.truelist);
  	line* list = id2.truelist;
  	line* list2 = id2.falselist;
  	
	while(list != NULL){
		result_string = (char *)malloc(100 * sizeof(char));
		strcpy(result_string, "");
		
		aux = varc3a.code[list->linenum];
		
		num = list->linenum+1;
		sprintf(temp,"%i", num);
		strcat(result_string , temp);
		strcat(result_string , ": IF ");
		strcat(result_string , id.name);
		strcat(result_string , " EQ ");
		strcat(result_string , aux);
		
		
		varc3a.code[list->linenum] = result_string;
		list = list->nextLine;
	}
	
	list = id2.truelist;
	list = list->nextLine;
	while(list2 != NULL){
		result_string = (char *)malloc(100 * sizeof(char));
		strcpy(result_string, "");
		
		aux = varc3a.code[list2->linenum];
		
		if(list == NULL){
			num = varc3a.num;
			sprintf(temp,"%i", num);
			strcat(aux, temp);
			strcat(aux, "\n");
			varc3a.code[list2->linenum] = aux;
		}else{
			num = list->linenum+1;
			sprintf(temp,"%i", num);
			strcat(aux, temp);
			strcat(aux, "\n");
			varc3a.code[list2->linenum] = aux;
			
			list = list->nextLine;
		}
		
		list2 = list2->nextLine;
	}
	
}

char * print_func(value_info id){
	char * aux = malloc(100);
	strcpy(aux, "PUT");
	if(id.val_type == INT_TYPE){
		strcat(aux, "I");
	}
	if(id.val_type == FLOAT_TYPE){
		strcat(aux, "F");
	}
	return aux;
}
char * print_func2(value_info id){
	char * aux;
	if(id.val_type == BOOLEAN_TYPE){if(id.boolean == 1){aux = "true";}else{aux = "false";}}
	if(id.val_type == INT_TYPE){
		if(id.hex_oct == 0){
			aux =malloc(sizeof(int)+1);
			sprintf(aux, "%i", id.val_int);
		}
		if(id.hex_oct == 1){
			aux = ch_int_oct(id.val_int);
		}
		if(id.hex_oct == 2){
			aux = ch_int_hex(id.val_int);
		}
	}
	if(id.val_type == FLOAT_TYPE){aux =malloc(sizeof(float)+1);
		sprintf(aux, "%f", id.val_float);}
	if(id.val_type == STRING_TYPE){aux = id.val_string;}
	return aux;
	
}

char * print_type(value_info id){
	char * aux;
	if(id.val_type == BOOLEAN_TYPE){aux = "BOOLEAN";}
	if(id.val_type == INT_TYPE){
		if(id.hex_oct == 0){aux = "INT";}
		if(id.hex_oct == 1){aux = "OCTAL";}
		if(id.hex_oct == 2){aux = "HEXADECIMAL";}
	
	}
	if(id.val_type == FLOAT_TYPE){aux = "FLOAT";}
	if(id.val_type == STRING_TYPE){aux = "STRING";}
	
	return aux;
	
}

void print_assign_array(value_info id, value_info exp, value_info exp2){
	extern C3A varc3a;
	char * i = num_lin();
	char * aux = malloc(100);
	
	if(exp.val_type != INT_TYPE){
		yylineno--;
		yyerror("Semantical error: the displaement only can be Integer");
	}else{
		
		char *result_string = (char *)malloc(100 * sizeof(char)); 

	   	
	   	strcpy(result_string, "");
	    	char temp[50]; 
	    	sprintf(temp, "%i", varc3a.num);
	    	strcat(result_string, temp);
	    	strcat(result_string, ": ");
	    	strcat(result_string, i);
	   	strcat(result_string, " := ");
	    	strcat(result_string, exp.name);
	    	strcat(result_string, " MULI 4");
	    	strcat(result_string, "\n");
	    	
		print_code(result_string);
		
		strcpy(result_string, "");
    		sprintf(temp, "%i", varc3a.num);
    		strcpy(result_string, temp);
	    	strcat(result_string, ": ");
	    	strcat(result_string, id.name);
	    	strcat(result_string, "[");
	    	strcat(result_string, i);
	    	strcat(result_string, "] := ");
	    	strcat(result_string, exp2.name);
	    	
	    	print_code(result_string);
			
		strcpy(exp2.name, id.name);
		strcat(exp2.name, "[");
		sprintf(aux, "%i", exp.val_int);
		strcat(exp2.name, aux);
		strcat(exp2.name, "]");
		strcat(result_string, "\n");
		
		sym_enter(exp2.name, (void*) &exp2);
		free(result_string);
	}
}

value_info print_array(value_info id, value_info exp){
	value_info aux;
	extern C3A varc3a;
	char * i = num_lin();
	char * sym = malloc(100);
	
	strcpy(sym, id.name);
	strcat(sym, "[");
	strcat(sym, exp.name);
	strcat(sym, "]");
	
	if(sym_lookup(sym, (void *) &aux)== SYMTAB_NOT_FOUND){
		yylineno--;
		yyerror("Semantical error: Id is not initialized");
		aux.val_type = 1;
	}else{
	
		if(exp.val_type != INT_TYPE){
			yylineno--;
			yyerror("Semantical error: the displaement only can be Integer");
		}else{
			char *result_string = (char *)malloc(100 * sizeof(char)); 

	   		strcpy(result_string, "");
	    		char temp[50]; 
	    		sprintf(temp, "%i", varc3a.num);
		    	strcpy(result_string, temp);
		    	strcat(result_string, ": ");
		    	strcat(result_string, i);
		    	strcat(result_string, " := ");
		    	strcat(result_string, exp.name);
		    	strcat(result_string, " MULI 4\n");

			print_code(result_string);
			
			exp.name = i;
			i = num_lin();
			strcpy(result_string, "");
		    	sprintf(temp, "%i", varc3a.num);
		    	strcat(result_string, temp);
		    	strcat(result_string, ": ");
		    	strcat(result_string, i);
		    	strcat(result_string, " := ");
		    	strcat(result_string, id.name);
		    	strcat(result_string, "[");
		    	strcat(result_string, exp.name);
		    	strcat(result_string, "]\n");
		    	
		    	print_code(result_string);
		    	
			free(result_string);
		}
		aux.name = i;
	}
	return aux;
}


value_info or_func(value_info id1, value_info id2){
	value_info aux;
	extern C3A varc3a;

	if (id1.val_type == BOOLEAN_TYPE && id2.val_type == BOOLEAN_TYPE){
		aux.boolean = id1.boolean || id2.boolean;
		aux.val_type = BOOLEAN_TYPE;
	
		aux.truelist = unionList(id1.truelist, id2.truelist);
	    	aux.falselist = id2.falselist;
		
		addGoto(id1.falselist, varc3a.num-2);
		
	}else{
		yylineno--;
		yyerror("Semantical error: the literal have to be Boolean");
	}
	return aux;
}

value_info and_func(value_info id1, value_info id2){
	value_info aux;
	extern C3A varc3a;
	
	if (id1.val_type == BOOLEAN_TYPE && id2.val_type == BOOLEAN_TYPE){
		aux.boolean = id1.boolean && id2.boolean;
		aux.val_type = BOOLEAN_TYPE;
		
		addGoto(id1.truelist, varc3a.num-2);
		
		aux.truelist = id2.truelist;
		aux.falselist = unionList(id1.falselist, id2.falselist);
	    	
	}else{
		yylineno--;
		yyerror("Semantical error: the literal have to be Boolean");
	}
	return aux;
}

value_info not_func(value_info id1){
	value_info aux;

	if (id1.val_type == BOOLEAN_TYPE){
		aux.boolean = !id1.boolean;
		aux.val_type = BOOLEAN_TYPE;
	}else{
		yylineno--;
		yyerror("Semantical error: the literal have to be Boolean");
	}
	return aux;
}

value_info gt_func(value_info id1, value_info id2){
	value_info aux;
	extern C3A varc3a;
	char *result_string = (char *)malloc(100 * sizeof(char)); // Asumiendo un tamaño suficientemente grande
   	strcpy(result_string, "");
    	char temp[50];
	
	if (id1.val_type == STRING_TYPE || id2.val_type == STRING_TYPE){
		yylineno--;
		yyerror("Semantical error: String value can not be compared");
	}
	if (id1.val_type == BOOLEAN_TYPE || id2.val_type == BOOLEAN_TYPE) {
		yylineno--;
		yyerror("Semantical error: Boolean type literals can not be compared");
	}
	if (id1.val_type == INT_TYPE && id2.val_type == INT_TYPE){
		aux.boolean = id1.val_int > id2.val_int;
		aux.val_type = BOOLEAN_TYPE;
		sprintf(temp, "%i", varc3a.num);
	    	strcpy(result_string, temp);

	    	strcat(result_string, ": IF ");
	    	strcat(result_string, id1.name);
	    	strcat(result_string, " GTI ");
	    	strcat(result_string, id2.name);
	    	strcat(result_string, " GOTO ");
	    	
	    	print_code(result_string);

	}
	if (id1.val_type == FLOAT_TYPE && id2.val_type == FLOAT_TYPE){
		aux.boolean = id1.val_float > id2.val_float;
		aux.val_type = BOOLEAN_TYPE;
		sprintf(temp, "%i", varc3a.num);
	    	strcpy(result_string, temp);

	    	strcat(result_string, ": IF ");
	    	strcat(result_string, id1.name);
	    	strcat(result_string, " GTF ");
	    	strcat(result_string, id2.name);
	    	strcat(result_string, " GOTO ");
	    	
	    	print_code(result_string);
	}
	if (id1.val_type == INT_TYPE && id2.val_type == FLOAT_TYPE){
		aux.boolean = (float) id1.val_int > id2.val_float;
		aux.val_type = BOOLEAN_TYPE;
		sprintf(temp, "%i", varc3a.num);
	    	strcpy(result_string, temp);

	    	strcat(result_string, ": IF ");
	    	strcat(result_string, id1.name);
	    	strcat(result_string, " GTF ");
	    	strcat(result_string, id2.name);
	    	strcat(result_string, " GOTO ");
	    	
	    	print_code(result_string);
	}
	if (id1.val_type == FLOAT_TYPE && id2.val_type == INT_TYPE){
		aux.boolean =  id1.val_float > (float)id2.val_int;
		aux.val_type = BOOLEAN_TYPE;
		sprintf(temp, "%i", varc3a.num);
	    	strcpy(result_string, temp);

	    	strcat(result_string, ": IF ");
	    	strcat(result_string, id1.name);
	    	strcat(result_string, " GTF ");
	    	strcat(result_string, id2.name);
	    	strcat(result_string, " GOTO ");
	    	
	    	print_code(result_string);
	}
	sprintf(temp, "%i", varc3a.num);
	strcpy(result_string, temp);
	strcat(result_string, ": GOTO ");
	aux.truelist = addList();
	    	
	print_code(result_string);
	free(result_string);
	
	aux.falselist = addList();
	
	return aux;
}

value_info ge_func(value_info id1, value_info id2){
	value_info aux;
	extern C3A varc3a;
	char *result_string = (char *)malloc(100 * sizeof(char)); // Asumiendo un tamaño suficientemente grande
   	strcpy(result_string, "");
    	char temp[50];
	
	if (id1.val_type == STRING_TYPE || id2.val_type == STRING_TYPE){
		yylineno--;
		yyerror("Semantical error: String value can not be compared");
	}
	if (id1.val_type == BOOLEAN_TYPE || id2.val_type == BOOLEAN_TYPE) {
		yylineno--;
		yyerror("Semantical error: Boolean type literals can not be compared");
	}
	if (id1.val_type == INT_TYPE && id2.val_type == INT_TYPE){
		aux.boolean = id1.val_int >= id2.val_int;
		aux.val_type = BOOLEAN_TYPE;
		sprintf(temp, "%i", varc3a.num);
	    	strcpy(result_string, temp);

	    	strcat(result_string, ": IF ");
	    	strcat(result_string, id1.name);
	    	strcat(result_string, " GEI ");
	    	strcat(result_string, id2.name);
	    	strcat(result_string, " GOTO ");
	    	
	    	print_code(result_string);
	}
	if (id1.val_type == FLOAT_TYPE && id2.val_type == FLOAT_TYPE){
		aux.boolean = id1.val_float >= id2.val_float;
		aux.val_type = BOOLEAN_TYPE;
		sprintf(temp, "%i", varc3a.num);
	    	strcpy(result_string, temp);

	    	strcat(result_string, ": IF ");
	    	strcat(result_string, id1.name);
	    	strcat(result_string, " GEF ");
	    	strcat(result_string, id2.name);
	    	strcat(result_string, " GOTO ");
	    	
	    	print_code(result_string);
	}
	if (id1.val_type == INT_TYPE && id2.val_type == FLOAT_TYPE){
		aux.boolean = (float) id1.val_int >= id2.val_float;
		aux.val_type = BOOLEAN_TYPE;
		sprintf(temp, "%i", varc3a.num);
	    	strcpy(result_string, temp);

	    	strcat(result_string, ": IF ");
	    	strcat(result_string, id1.name);
	    	strcat(result_string, " GEF ");
	    	strcat(result_string, id2.name);
	    	strcat(result_string, " GOTO ");
	    	
	    	print_code(result_string);
	}
	if (id1.val_type == FLOAT_TYPE && id2.val_type == INT_TYPE){
		aux.boolean =  id1.val_float >= (float)id2.val_int;
		aux.val_type = BOOLEAN_TYPE;
	}
	sprintf(temp, "%i", varc3a.num);
	strcpy(result_string, temp);
	strcat(result_string, ": GOTO ");
	aux.truelist = addList();
	    	
	print_code(result_string);
	free(result_string);
	
	aux.falselist = addList();
	return aux;
}

value_info lt_func(value_info id1, value_info id2){
	value_info aux;
	extern C3A varc3a;
	char *result_string = (char *)malloc(100 * sizeof(char)); // Asumiendo un tamaño suficientemente grande
   	strcpy(result_string, "");
    	char temp[50];
	
	if (id1.val_type == STRING_TYPE || id2.val_type == STRING_TYPE){
		yylineno--;
		yyerror("Semantical error: String value can not be compared");
	}
	if (id1.val_type == BOOLEAN_TYPE || id2.val_type == BOOLEAN_TYPE) {
		yylineno--;
		yyerror("Semantical error: Boolean type literals can not be compared");
	}
	if (id1.val_type == INT_TYPE && id2.val_type == INT_TYPE){
		aux.boolean = id1.val_int < id2.val_int;
		aux.val_type = BOOLEAN_TYPE;
		sprintf(temp, "%i", varc3a.num);
	    	strcpy(result_string, temp);

	    	strcat(result_string, ": IF ");
	    	strcat(result_string, id1.name);
	    	strcat(result_string, " LTI ");
	    	strcat(result_string, id2.name);
	    	strcat(result_string, " GOTO ");
	    	
	    	print_code(result_string);
	}
	if (id1.val_type == FLOAT_TYPE && id2.val_type == FLOAT_TYPE){
		aux.boolean = id1.val_float < id2.val_float;
		aux.val_type = BOOLEAN_TYPE;
		sprintf(temp, "%i", varc3a.num);
	    	strcpy(result_string, temp);

	    	strcat(result_string, ": IF ");
	    	strcat(result_string, id1.name);
	    	strcat(result_string, " LTF ");
	    	strcat(result_string, id2.name);
	    	strcat(result_string, " GOTO ");
	    	
	    	print_code(result_string);
	}
	if (id1.val_type == INT_TYPE && id2.val_type == FLOAT_TYPE){
		aux.boolean = (float) id1.val_int < id2.val_float;
		aux.val_type = BOOLEAN_TYPE;
		sprintf(temp, "%i", varc3a.num);
	    	strcpy(result_string, temp);

	    	strcat(result_string, ": IF ");
	    	strcat(result_string, id1.name);
	    	strcat(result_string, " LTF ");
	    	strcat(result_string, id2.name);
	    	strcat(result_string, " GOTO ");
	    	
	    	print_code(result_string);
	}
	if (id1.val_type == FLOAT_TYPE && id2.val_type == INT_TYPE){
		aux.boolean =  id1.val_float < (float)id2.val_int;
		aux.val_type = BOOLEAN_TYPE;
		sprintf(temp, "%i", varc3a.num);
	    	strcpy(result_string, temp);

	    	strcat(result_string, ": IF ");
	    	strcat(result_string, id1.name);
	    	strcat(result_string, " LTF ");
	    	strcat(result_string, id2.name);
	    	strcat(result_string, " GOTO ");
	    	
	    	print_code(result_string);
	}
	sprintf(temp, "%i", varc3a.num);
	strcpy(result_string, temp);
	strcat(result_string, ": GOTO ");
	aux.truelist = addList();
	    	
	print_code(result_string);
	free(result_string);
	
	aux.falselist = addList();
	return aux;
}

value_info le_func(value_info id1, value_info id2){
	value_info aux;
	extern C3A varc3a;
	char *result_string = (char *)malloc(100 * sizeof(char)); // Asumiendo un tamaño suficientemente grande
   	strcpy(result_string, "");
    	char temp[50];
	
	if (id1.val_type == STRING_TYPE || id2.val_type == STRING_TYPE){
		yylineno--;
		yyerror("Semantical error: String value can not be compared");
	}
	if (id1.val_type == BOOLEAN_TYPE || id2.val_type == BOOLEAN_TYPE) {
		yylineno--;
		yyerror("Semantical error: Boolean type literals can not be compared");
	}
	if (id1.val_type == INT_TYPE && id2.val_type == INT_TYPE){
		aux.boolean = id1.val_int <= id2.val_int;
		aux.val_type = BOOLEAN_TYPE;
		sprintf(temp, "%i", varc3a.num);
	    	strcpy(result_string, temp);

	    	strcat(result_string, ": IF ");
	    	strcat(result_string, id1.name);
	    	strcat(result_string, " LEI ");
	    	strcat(result_string, id2.name);
	    	strcat(result_string, " GOTO ");
	    	
	    	print_code(result_string);
	}
	if (id1.val_type == FLOAT_TYPE && id2.val_type == FLOAT_TYPE){
		aux.boolean = id1.val_float <= id2.val_float;
		aux.val_type = BOOLEAN_TYPE;
		sprintf(temp, "%i", varc3a.num);
	    	strcpy(result_string, temp);

	    	strcat(result_string, ": IF ");
	    	strcat(result_string, id1.name);
	    	strcat(result_string, " LEF ");
	    	strcat(result_string, id2.name);
	    	strcat(result_string, " GOTO ");
	    	
	    	print_code(result_string);
	}
	if (id1.val_type == INT_TYPE && id2.val_type == FLOAT_TYPE){
		aux.boolean = (float) id1.val_int <= id2.val_float;
		aux.val_type = BOOLEAN_TYPE;
		sprintf(temp, "%i", varc3a.num);
	    	strcpy(result_string, temp);

	    	strcat(result_string, ": IF ");
	    	strcat(result_string, id1.name);
	    	strcat(result_string, " LEF ");
	    	strcat(result_string, id2.name);
	    	strcat(result_string, " GOTO ");
	    	
	    	print_code(result_string);
	}
	if (id1.val_type == FLOAT_TYPE && id2.val_type == INT_TYPE){
		aux.boolean =  id1.val_float <= (float)id2.val_int;
		aux.val_type = BOOLEAN_TYPE;
		sprintf(temp, "%i", varc3a.num);
	    	strcpy(result_string, temp);

	    	strcat(result_string, ": IF ");
	    	strcat(result_string, id1.name);
	    	strcat(result_string, " LEF ");
	    	strcat(result_string, id2.name);
	    	strcat(result_string, " GOTO ");
	    	
	    	print_code(result_string);
	}
	sprintf(temp, "%i", varc3a.num);
	strcpy(result_string, temp);
	strcat(result_string, ": GOTO ");
	aux.truelist = addList();
	    	
	print_code(result_string);
	free(result_string);
	
	aux.falselist = addList();
	return aux;
}

value_info eq_func(value_info id1, value_info id2){
	value_info aux;
	extern C3A varc3a;
	char *result_string = (char *)malloc(100 * sizeof(char)); // Asumiendo un tamaño suficientemente grande
   	strcpy(result_string, "");
    	char temp[50];
	
	if (id1.val_type == STRING_TYPE || id2.val_type == STRING_TYPE){
		yylineno--;
		yyerror("Semantical error: String value can not be compared");
	}
	if (id1.val_type == BOOLEAN_TYPE || id2.val_type == BOOLEAN_TYPE) {
		yylineno--;
		yyerror("Semantical error: Boolean type literals can not be compared");
	}
	if (id1.val_type == INT_TYPE && id2.val_type == INT_TYPE){
		aux.boolean = id1.val_int == id2.val_int;
		aux.val_type = BOOLEAN_TYPE;
		sprintf(temp, "%i", varc3a.num);
	    	strcpy(result_string, temp);

	    	strcat(result_string, ": IF ");
	    	strcat(result_string, id1.name);
	    	strcat(result_string, " EQI ");
	    	strcat(result_string, id2.name);
	    	strcat(result_string, " GOTO ");
	    	
	    	print_code(result_string);
	}
	if (id1.val_type == FLOAT_TYPE && id2.val_type == FLOAT_TYPE){
		aux.boolean = id1.val_float == id2.val_float;
		aux.val_type = BOOLEAN_TYPE;
		sprintf(temp, "%i", varc3a.num);
	    	strcpy(result_string, temp);

	    	strcat(result_string, ": IF ");
	    	strcat(result_string, id1.name);
	    	strcat(result_string, " EQF ");
	    	strcat(result_string, id2.name);
	    	strcat(result_string, " GOTO ");
	    	
	    	print_code(result_string);
	}
	if (id1.val_type == INT_TYPE && id2.val_type == FLOAT_TYPE){
		aux.boolean = (float) id1.val_int == id2.val_float;
		aux.val_type = BOOLEAN_TYPE;
		sprintf(temp, "%i", varc3a.num);
	    	strcpy(result_string, temp);

	    	strcat(result_string, ": IF ");
	    	strcat(result_string, id1.name);
	    	strcat(result_string, " EQF ");
	    	strcat(result_string, id2.name);
	    	strcat(result_string, " GOTO ");
	    	
	    	print_code(result_string);
	}
	if (id1.val_type == FLOAT_TYPE && id2.val_type == INT_TYPE){
		aux.boolean =  id1.val_float == (float)id2.val_int;
		aux.val_type = BOOLEAN_TYPE;
		sprintf(temp, "%i", varc3a.num);
	    	strcpy(result_string, temp);

	    	strcat(result_string, ": IF ");
	    	strcat(result_string, id1.name);
	    	strcat(result_string, " EQF ");
	    	strcat(result_string, id2.name);
	    	strcat(result_string, " GOTO ");
	    	
	    	print_code(result_string);
	}
	sprintf(temp, "%i", varc3a.num);
	strcpy(result_string, temp);
	strcat(result_string, ": GOTO ");
	aux.truelist = addList();
	    	
	print_code(result_string);
	free(result_string);
	
	aux.falselist = addList();
	return aux;
}

value_info ne_func(value_info id1, value_info id2){
	value_info aux;
	extern C3A varc3a;
	char *result_string = (char *)malloc(100 * sizeof(char)); // Asumiendo un tamaño suficientemente grande
   	strcpy(result_string, "");
    	char temp[50];
	
	if (id1.val_type == STRING_TYPE || id2.val_type == STRING_TYPE){
		yylineno--;
		yyerror("Semantical error: String value can not be compared");
	}
	if (id1.val_type == BOOLEAN_TYPE || id2.val_type == BOOLEAN_TYPE) {
		yylineno--;
		yyerror("Semantical error: Boolean type literals can not be compared");
	}
	if (id1.val_type == INT_TYPE && id2.val_type == INT_TYPE){
		aux.boolean = id1.val_int != id2.val_int;
		aux.val_type = BOOLEAN_TYPE;
		sprintf(temp, "%i", varc3a.num);
	    	strcpy(result_string, temp);

	    	strcat(result_string, ": IF ");
	    	strcat(result_string, id1.name);
	    	strcat(result_string, " NEI ");
	    	strcat(result_string, id2.name);
	    	strcat(result_string, " GOTO ");
	    	
	    	print_code(result_string);
	}
	if (id1.val_type == FLOAT_TYPE && id2.val_type == FLOAT_TYPE){
		aux.boolean = id1.val_float != id2.val_float;
		aux.val_type = BOOLEAN_TYPE;
		sprintf(temp, "%i", varc3a.num);
	    	strcpy(result_string, temp);

	    	strcat(result_string, ": IF ");
	    	strcat(result_string, id1.name);
	    	strcat(result_string, " NEF ");
	    	strcat(result_string, id2.name);
	    	strcat(result_string, " GOTO ");
	    	
	    	print_code(result_string);
	}
	if (id1.val_type == INT_TYPE && id2.val_type == FLOAT_TYPE){
		aux.boolean = (float) id1.val_int != id2.val_float;
		aux.val_type = BOOLEAN_TYPE;
		sprintf(temp, "%i", varc3a.num);
	    	strcpy(result_string, temp);

	    	strcat(result_string, ": IF ");
	    	strcat(result_string, id1.name);
	    	strcat(result_string, " NEF ");
	    	strcat(result_string, id2.name);
	    	strcat(result_string, " GOTO ");
	    	
	    	print_code(result_string);
	}
	if (id1.val_type == FLOAT_TYPE && id2.val_type == INT_TYPE){
		aux.boolean =  id1.val_float != (float)id2.val_int;
		aux.val_type = BOOLEAN_TYPE;
		sprintf(temp, "%i", varc3a.num);
	    	strcpy(result_string, temp);

	    	strcat(result_string, ": IF ");
	    	strcat(result_string, id1.name);
	    	strcat(result_string, " NEF ");
	    	strcat(result_string, id2.name);
	    	strcat(result_string, " GOTO ");
	    	
	    	print_code(result_string);
	}
	sprintf(temp, "%i", varc3a.num);
	strcpy(result_string, temp);
	strcat(result_string, ": GOTO ");
	aux.truelist = addList();
	    	
	print_code(result_string);
	free(result_string);
	
	aux.falselist = addList();
	return aux;
}



value_info sin_a(value_info id1){
	value_info aux;
	aux.hex_oct = id1.hex_oct;
	float ent;
	
	if (id1.val_type == STRING_TYPE ){
		yylineno--;
		yyerror("Semantical error: Sin function can not use string types");
	}
	if (id1.val_type == BOOLEAN_TYPE ) {
		yylineno--;
		yyerror("Semantical error: Sin function can not use boolean types");
	}
	if (id1.val_type == INT_TYPE){
		ent = calcularSeno((float)id1.val_int);
		aux.val_float = ent;
		aux.val_type = FLOAT_TYPE;
		
	}
	if (id1.val_type == FLOAT_TYPE){
		ent = calcularSeno(id1.val_float);
		aux.val_float = ent;
		aux.val_type = FLOAT_TYPE;
		
	}
	
	return aux;
}

value_info cos_a(value_info id1){
	value_info aux;
	aux.hex_oct = id1.hex_oct;
	float ent;
	
	if (id1.val_type == STRING_TYPE ){
		yylineno--;
		yyerror("Semantical error: Cos function can not use string types");
	}
	if (id1.val_type == BOOLEAN_TYPE ) {
		yylineno--;
		yyerror("Semantical error: Cos function can not use boolean types");
	}
	if (id1.val_type == INT_TYPE){
		ent = calcularCoseno((float)id1.val_int);
		aux.val_float = ent;
		aux.val_type = FLOAT_TYPE;
		
	}
	if (id1.val_type == FLOAT_TYPE){
		ent = calcularCoseno(id1.val_float);
		aux.val_float = ent;
		aux.val_type = FLOAT_TYPE;
		
	}
	
	return aux;
}

value_info tan_a(value_info id1){
	value_info aux;
	aux.hex_oct = id1.hex_oct;
	float ent;
	
	if (id1.val_type == STRING_TYPE ){
		yylineno--;
		yyerror("Semantical error: Tan function can not use string types");
	}
	if (id1.val_type == BOOLEAN_TYPE ) {
		yylineno--;
		yyerror("Semantical error: Tan function can not use boolean types");
	}
	if (id1.val_type == INT_TYPE){
		ent = calcularTangente((float)id1.val_int);
		aux.val_float = ent;
		aux.val_type = FLOAT_TYPE;
		
	}
	if (id1.val_type == FLOAT_TYPE){
		ent = calcularTangente(id1.val_float);
		aux.val_float = ent;
		aux.val_type = FLOAT_TYPE;
		
	}
	
	return aux;
}

float factorial(int n) {
    if (n <= 1)
        return 1;
    else
        return n * factorial(n - 1);
}

float calcularSeno(float grados) {
    float radianes = grados * 3.141592653589793 / 180.0; // Conversión a radianes
    float x = radianes;
    float sinx = x;
    int signo = -1;
    int i;

    for (i = 3; i <= 15; i += 2) { // Suma de términos de la serie hasta el término 15
        x *= radianes * radianes; // Potencias de x
        sinx += signo * x / factorial(i); // Términos de la serie
        signo *= -1; // Cambio de signo para el siguiente término
    }

    return sinx;
}

float calcularCoseno(float grados) {
    float radianes = grados * 3.141592653589793 / 180.0;
    double cos = 1.0;
    int sign = -1;
    for (int i = 2; i <= 10; i += 2) { // Usando los primeros términos de la serie
        double potencia = 1.0;
        for (int j = 1; j <= i; ++j) {
            potencia *= radianes;
        }
        cos += (sign * potencia) / factorial(i);
        sign *= -1;
    }
    return cos;
}

float calcularTangente(float grados) {
    float seno = calcularSeno(grados);
    float coseno = calcularCoseno(grados);

    // Verificar si el coseno es cercano a 0 para evitar división por 0
    if (coseno < 0.000001 && coseno > -0.000001) {
        printf("Error: El coseno es cercano a 0. La tangente es indefinida.\n");
        return 0.0; // Otra acción apropiada para manejar este caso
    }

    return seno / coseno; // Calcular la tangente como el cociente del seno y el coseno
}


value_info str(value_info id1){
	value_info aux;
	aux.hex_oct = id1.hex_oct;
	int lon = 0;
	if (id1.val_type != STRING_TYPE){
		yylineno--;
		yyerror("Semantical error: no String type literals can not use strlen");
	}else{
		while(id1.val_string[lon] != '\0'){
			lon++;
		}
	}
	aux.val_int = lon;
	aux.val_type = INT_TYPE;
	return aux;
}

value_info ch_sign(value_info id1){
	value_info aux;
	extern C3A varc3a;
	aux.hex_oct = id1.hex_oct;
	char *result_string = (char *)malloc(100 * sizeof(char));
	strcpy(result_string, "");
    	char temp[50];
    	char * i = num_lin();
	if (id1.val_type == BOOLEAN_TYPE) {
		yylineno--;
		yyerror("Semantical error: Boolean type literals can not be changed sign");
	}
	if (id1.val_type == STRING_TYPE){
		yylineno--;
		yyerror("Semantical error: String type literals can not be changed signn");
	}
	if (id1.val_type == INT_TYPE){
		aux.val_int = -id1.val_int;
		aux.val_type = INT_TYPE;
		
		sprintf(temp, "%i", varc3a.num);
	    	strcat(result_string, temp);
	    	strcat(result_string, ": ");
	    	strcat(result_string, i);
	    	strcat(result_string, " := CHSI ");
	    	strcat(result_string, id1.name);
	    	strcat(result_string, "\n");
	    	print_code(result_string);
	    	
	}
	if (id1.val_type == FLOAT_TYPE){
		aux.val_float = -id1.val_float;
		aux.val_type = FLOAT_TYPE;
		
		sprintf(temp, "%i", varc3a.num);
	    	strcat(result_string, temp);
	    	strcat(result_string, ": ");
	    	strcat(result_string, i);
	    	strcat(result_string, " := CHSF ");
	    	strcat(result_string, id1.name);
	    	strcat(result_string, "\n");
	    	print_code(result_string);
	}
	aux.name = i;
	return aux;
}

value_info print_do(){
	value_info aux;
	extern C3A varc3a;
	
	aux.name = num_lin();
	aux.val_int = varc3a.num;
	char *result_string = (char *)malloc(100 * sizeof(char));
	
	strcpy(result_string, "");
    	char temp[50];
    	sprintf(temp, "%i", varc3a.num);
    	strcat(result_string, temp);
    	strcat(result_string, ": ");
    	strcat(result_string, aux.name);
    	strcat(result_string, " := 0\n");
    	
    	print_code(result_string);
    	
	
	return aux;
}

void print_final(value_info id, char * exp){
	extern C3A varc3a;
	char *result_string = (char *)malloc(100 * sizeof(char));
	
	strcpy(result_string, "");
    	char temp[50];
    	sprintf(temp, "%i", varc3a.num);
    	strcat(result_string, temp);
    	strcat(result_string, ": ");
    	strcat(result_string, id.name);
    	strcat(result_string, " := ");
    	strcat(result_string, id.name);
    	strcat(result_string, " ADDI 1\n");
    	
    	print_code(result_string);
    	
	//printf("%i: %s := %s ADDI 1\n", varc3a.num, id.name, id.name);
	
	strcpy(result_string, "");
    	sprintf(temp, "%i", varc3a.num);
    	strcpy(result_string, temp);
    	strcat(result_string, ": IF ");
    	strcat(result_string, id.name);
    	strcat(result_string, " LTI ");
    	strcat(result_string, exp);
    	strcat(result_string, " GOTO ");
    	sprintf(temp, "%i", id.val_int + 1);
    	strcat(result_string, temp);
    	strcat(result_string, "\n");
    	
    	print_code(result_string);
    	
    	free(result_string);

	//printf("%i: IF %s LTI %s GOTO %i\n", varc3a.num, id.name, exp, id.val_int+1);
	
}
void print_id(char * id1, char * id2){
	extern C3A varc3a;
	
	char *result_string = (char *)malloc(100 * sizeof(char)); // Asumiendo un tamaño suficientemente grande
    	strcpy(result_string, "");
    	char temp[50];
    	sprintf(temp, "%i", varc3a.num);
    	strcpy(result_string, temp);
    	strcat(result_string, ": ");
    	strcat(result_string, id1);
    	strcat(result_string, " := ");
    	strcat(result_string, id2);
   	strcat(result_string, "\n");

    	print_code(result_string);

    	free(result_string);
}
void print_exp(value_info id1){
	extern C3A varc3a;
	char *result_string = (char *)malloc(100 * sizeof(char)); // Asumiendo un tamaño suficientemente grande
	
	if (id1.val_type == INT_TYPE || id1.val_type == FLOAT_TYPE){
	    	strcpy(result_string, "");
	    	char temp[50];
	    	sprintf(temp, "%i", varc3a.num);
	    	strcpy(result_string, temp);
	    	strcat(result_string, ": PARAM ");
	    	strcat(result_string, id1.name);
	    	strcat(result_string, "\n");

	   	print_code(result_string);
	   	
	   	strcpy(result_string, "");
	   	sprintf(temp, "%i", varc3a.num);
	    	strcpy(result_string, temp);
	    	strcat(result_string, ": CALL ");
	    	strcat(result_string, print_func(id1)); 
	    	strcat(result_string, ", 1\n");

	    	print_code(result_string);

	    	free(result_string);
	}
}

char* num_lin(){
	char* aux = malloc(sizeof(int) + 1);
    	extern C3A varc3a;

    	sprintf(aux, "%i", varc3a.tmp);

   	char* res;
    	if (varc3a.tmp < 10) {
    	    res = malloc(strlen("$t0") + strlen(aux) + 1);
    	    strcpy(res, "$t0");
   	    strcat(res, aux);
   	} else {
            res = malloc(strlen("$t") + strlen(aux) + 1);
            strcpy(res, "$t");
       	    strcat(res, aux);
    	}

    	free(aux); 
    	varc3a.tmp = varc3a.tmp + 1;
    	return res;
}

value_info add(value_info id1, value_info id2){
	value_info aux;
	
	aux.hex_oct = id1.hex_oct;
	extern C3A varc3a;
	aux.name = malloc(100);
	char * i = num_lin();
	char *result_string = (char *)malloc(100 * sizeof(char)); // Asumiendo un tamaño suficientemente grande
    	strcpy(result_string, "");
    	char temp[50];

	if(id1.val_type == 1 || id2.val_type == 1){
		yylineno--;
		yyerror("Semantical error: value can be inicialized");
		aux.val_type = 1;
	}else{
		if (id1.val_type == BOOLEAN_TYPE || id2.val_type == BOOLEAN_TYPE) {
			yylineno--;
			yyerror("Semantical error: Boolean type literals can not be added");
		}else if (id1.val_type == STRING_TYPE || id2.val_type == STRING_TYPE) {
			yylineno--;
			yyerror("Semantical error: String type literals can not be added");
		}else{
			if (id1.val_type == INT_TYPE && id2.val_type == INT_TYPE){
				aux.val_int = id1.val_int + id2.val_int;
				aux.val_type = INT_TYPE;
				
				strcpy(aux.name, i);
				strcat(aux.name, " := ");
				strcat(aux.name, id1.name);
				strcat(aux.name, " ADDI ");
	  			strcat(aux.name, id2.name);
			}
			if (id1.val_type == FLOAT_TYPE && id2.val_type == FLOAT_TYPE){
				aux.val_float = id1.val_float + id2.val_float;
				aux.val_type = FLOAT_TYPE;
				
				strcpy(aux.name, i);
				strcat(aux.name, " := ");
				strcat(aux.name, id1.name);
				strcat(aux.name, " ADDF ");
	  			strcat(aux.name, id2.name);
			}
			if (id1.val_type == INT_TYPE && id2.val_type == FLOAT_TYPE){
				aux.val_float = (float) id1.val_int + id2.val_float;
				aux.val_type = FLOAT_TYPE;
				
				strcpy(aux.name, i);
				strcat(aux.name, " := ");
				strcat(aux.name, "I2F ");
				strcat(aux.name, id1.name);
			
				strcpy(result_string, "");
			    	sprintf(temp, "%i", varc3a.num);
			    	strcpy(result_string, temp);
			    	strcat(result_string, ": ");
			    	strcat(result_string, aux.name);
			    	strcat(result_string, "\n");
			    	
			    	print_code(result_string);
			    	
				id1.name = i;
				i = num_lin();
				
				strcpy(aux.name, i);
				strcat(aux.name, " := ");
				strcat(aux.name, id1.name);
				strcat(aux.name, " ADDF ");
	  			strcat(aux.name, id2.name);
			}
			if (id1.val_type == FLOAT_TYPE && id2.val_type == INT_TYPE){
				aux.val_float =  id1.val_float + (float)id2.val_int;
				aux.val_type = FLOAT_TYPE;
				strcpy(aux.name, i);
				strcat(aux.name, " := ");
				strcat(aux.name, "I2F ");
				strcat(aux.name, id2.name);
				
				strcpy(result_string, "");
			    	sprintf(temp, "%i", varc3a.num);
			    	strcpy(result_string, temp);
			    	strcat(result_string, ": ");
			    	strcat(result_string, aux.name);
			    	strcat(result_string, "\n");
			    	
			    	print_code(result_string);
			    	
				id2.name = i;
				i = num_lin();
				
				strcpy(aux.name, i);
				strcat(aux.name, " := ");
				strcat(aux.name, id1.name);
				strcat(aux.name, " ADDF ");
	  			strcat(aux.name, id2.name);
			}
		}
		strcpy(result_string, "");
		sprintf(temp, "%i", varc3a.num);
		strcpy(result_string, temp);
		strcat(result_string, ": ");
		strcat(result_string, aux.name);
		strcat(result_string, "\n");
			    	
		print_code(result_string);
		aux.name = i;
	}
	free(result_string);
	return aux;
}

value_info sub(value_info id1, value_info id2){
	value_info aux;
	
	aux.hex_oct = id1.hex_oct;
	extern C3A varc3a;
	aux.name = malloc(100);
	char * i = num_lin();
	
	char *result_string = (char *)malloc(100 * sizeof(char)); // Asumiendo un tamaño suficientemente grande
    	strcpy(result_string, "");
    	char temp[50];

	if(id1.val_type == 1 || id2.val_type == 1){
		yylineno--;
		yyerror("Semantical error: value can be inicialized");
		aux.val_type = 1;
	}else{
		if (id1.val_type == BOOLEAN_TYPE || id2.val_type == BOOLEAN_TYPE) {
			yylineno--;
			yyerror("Semantical error: Boolean type literals can not be substracted");
		}
		if (id1.val_type == STRING_TYPE || id2.val_type == STRING_TYPE) {
			yylineno--;
			yyerror("Semantical error: String type literals can not be substracted");
		}
		if (id1.val_type == INT_TYPE && id2.val_type == INT_TYPE){
			aux.val_int = id1.val_int - id2.val_int;
			aux.val_type = INT_TYPE;
			
			strcpy(aux.name, i);
			strcat(aux.name, " := ");
			strcat(aux.name, id1.name);
			strcat(aux.name, " SUBI ");
  			strcat(aux.name, id2.name);
		}
		if (id1.val_type == FLOAT_TYPE && id2.val_type == FLOAT_TYPE){
			aux.val_float = id1.val_float - id2.val_float;
			aux.val_type = FLOAT_TYPE;
			
			strcpy(aux.name, i);
			strcat(aux.name, " := ");
			strcat(aux.name, id1.name);
			strcat(aux.name, " SUBF ");
  			strcat(aux.name, id2.name);
		}
		if (id1.val_type == INT_TYPE && id2.val_type == FLOAT_TYPE){
			aux.val_float = (float) id1.val_int - id2.val_float;
			aux.val_type = FLOAT_TYPE;
			
			strcpy(aux.name, i);
			strcat(aux.name, " := ");
			strcat(aux.name, "I2F ");
			strcat(aux.name, id1.name);
			
			strcpy(result_string, "");
			sprintf(temp, "%i", varc3a.num);
			strcpy(result_string, temp);
			strcat(result_string, ": ");
			strcat(result_string, aux.name);
			strcat(result_string, "\n");
			    	
			print_code(result_string);
			
			id1.name = i;
			i = num_lin();
			
			strcpy(aux.name, i);
			strcat(aux.name, " := ");
			strcat(aux.name, id1.name);
			strcat(aux.name, " SUBF ");
  			strcat(aux.name, id2.name);
		}
		if (id1.val_type == FLOAT_TYPE && id2.val_type == INT_TYPE){
			aux.val_float =  id1.val_float - (float)id2.val_int;
			aux.val_type = FLOAT_TYPE;
			strcpy(aux.name, i);
			strcat(aux.name, " := ");
			strcat(aux.name, "I2F ");
			strcat(aux.name, id2.name);
			
			strcpy(result_string, "");
			sprintf(temp, "%i", varc3a.num);
			strcpy(result_string, temp);
			strcat(result_string, ": ");
			strcat(result_string, aux.name);
			strcat(result_string, "\n");
			    	
			print_code(result_string);
			
			id2.name = i;
			i = num_lin();
			
			strcpy(aux.name, i);
			strcat(aux.name, " := ");
			strcat(aux.name, id1.name);
			strcat(aux.name, " SUBF ");
  			strcat(aux.name, id2.name);
		}
		strcpy(result_string, "");
		sprintf(temp, "%i", varc3a.num);
		strcpy(result_string, temp);
		strcat(result_string, ": ");
		strcat(result_string, aux.name);
		strcat(result_string, "\n");
			    	
		print_code(result_string);
		aux.name = i;
	}
	return aux;
}

value_info mul(value_info id1, value_info id2){
	value_info aux;
	
	aux.hex_oct = id1.hex_oct;
	extern C3A varc3a;
	aux.name = malloc(100);
	char * i = num_lin();
	
	char *result_string = (char *)malloc(100 * sizeof(char)); // Asumiendo un tamaño suficientemente grande
    	strcpy(result_string, "");
    	char temp[50];

	if(id1.val_type == 1 || id2.val_type == 1){
		yylineno--;
		yyerror("Semantical error: value can be inicialized");
		aux.val_type = 1;
	}else{
		if (id1.val_type == BOOLEAN_TYPE || id2.val_type == BOOLEAN_TYPE) {
			yylineno--;
			yyerror("Semantical error: Boolean type literals can not be multiplied");
		}
		if (id1.val_type == STRING_TYPE || id2.val_type == STRING_TYPE) {
			yylineno--;
			yyerror("Semantical error: String type literals can not be multiplied");
		}
		if (id1.val_type == INT_TYPE && id2.val_type == INT_TYPE){
			aux.val_int = id1.val_int * id2.val_int;
			aux.val_type = INT_TYPE;
			
			strcpy(aux.name, i);
			strcat(aux.name, " := ");
			strcat(aux.name, id1.name);
			strcat(aux.name, " MULI ");
  			strcat(aux.name, id2.name);
		}
		if (id1.val_type == FLOAT_TYPE && id2.val_type == FLOAT_TYPE){
			aux.val_float = id1.val_float * id2.val_float;
			aux.val_type = FLOAT_TYPE;
			
			strcpy(aux.name, i);
			strcat(aux.name, " := ");
			strcat(aux.name, id1.name);
			strcat(aux.name, " MULF ");
  			strcat(aux.name, id2.name);
		}
		if (id1.val_type == INT_TYPE && id2.val_type == FLOAT_TYPE){
			aux.val_float = (float) id1.val_int * id2.val_float;
			aux.val_type = FLOAT_TYPE;
			
			strcpy(aux.name, i);
			strcat(aux.name, " := ");
			strcat(aux.name, "I2F ");
			strcat(aux.name, id1.name);
			
			strcpy(result_string, "");
			sprintf(temp, "%i", varc3a.num);
			strcpy(result_string, temp);
			strcat(result_string, ": ");
			strcat(result_string, aux.name);
			strcat(result_string, "\n");
			    	
			print_code(result_string);
			
			id1.name = i;
			i = num_lin();
			
			strcpy(aux.name, i);
			strcat(aux.name, " := ");
			strcat(aux.name, id1.name);
			strcat(aux.name, " MULF ");
  			strcat(aux.name, id2.name);
		}
		if (id1.val_type == FLOAT_TYPE && id2.val_type == INT_TYPE){
			aux.val_float =  id1.val_float * (float)id2.val_int;
			aux.val_type = FLOAT_TYPE;
			strcpy(aux.name, i);
			strcat(aux.name, " := ");
			strcat(aux.name, "I2F ");
			strcat(aux.name, id2.name);
			
			strcpy(result_string, "");
			sprintf(temp, "%i", varc3a.num);
			strcpy(result_string, temp);
			strcat(result_string, ": ");
			strcat(result_string, aux.name);
			strcat(result_string, "\n");
			    	
			print_code(result_string);
			
			id2.name = i;
			i = num_lin();
			
			strcpy(aux.name, i);
			strcat(aux.name, " := ");
			strcat(aux.name, id1.name);
			strcat(aux.name, " MULF ");
  			strcat(aux.name, id2.name);
		}
		strcpy(result_string, "");
		sprintf(temp, "%i", varc3a.num);
		strcpy(result_string, temp);
		strcat(result_string, ": ");
		strcat(result_string, aux.name);
		strcat(result_string, "\n");
			    	
		print_code(result_string);
		aux.name = i;
	}
	
	return aux;
}

value_info div_a(value_info id1, value_info id2){
	value_info aux;
	
	aux.hex_oct = id1.hex_oct;
	extern C3A varc3a;
	aux.name = malloc(100);
	char * i = num_lin();
	char *result_string = (char *)malloc(100 * sizeof(char)); // Asumiendo un tamaño suficientemente grande
    	strcpy(result_string, "");
    	char temp[50];

	if(id1.val_type == 1 || id2.val_type == 1){
		yylineno--;
		yyerror("Semantical error: value can be inicialized");
		aux.val_type = 1;
	}else{
		if (id1.val_type == BOOLEAN_TYPE || id2.val_type == BOOLEAN_TYPE) {
			yylineno--;
			yyerror("Semantical error: Boolean type literals can not be divided");
		}
		if (id1.val_type == STRING_TYPE || id2.val_type == STRING_TYPE) {
			yylineno--;
			yyerror("Semantical error: String type literals can not be divided");
		}
		if (id1.val_type == INT_TYPE && id2.val_type == INT_TYPE){
			aux.val_int = id1.val_int / id2.val_int;
			aux.val_type = INT_TYPE;
			
			strcpy(aux.name, i);
			strcat(aux.name, " := ");
			strcat(aux.name, id1.name);
			strcat(aux.name, " DIVI ");
  			strcat(aux.name, id2.name);
		}
		if (id1.val_type == FLOAT_TYPE && id2.val_type == FLOAT_TYPE){
			aux.val_float = id1.val_float / id2.val_float;
			aux.val_type = FLOAT_TYPE;
			
			strcpy(aux.name, i);
			strcat(aux.name, " := ");
			strcat(aux.name, id1.name);
			strcat(aux.name, " DIVF ");
  			strcat(aux.name, id2.name);
		}
		if (id1.val_type == INT_TYPE && id2.val_type == FLOAT_TYPE){
			aux.val_float = (float) id1.val_int / id2.val_float;
			aux.val_type = FLOAT_TYPE;
			
			strcpy(aux.name, i);
			strcat(aux.name, " := ");
			strcat(aux.name, "I2F ");
			strcat(aux.name, id1.name);
			
			strcpy(result_string, "");
			sprintf(temp, "%i", varc3a.num);
			strcpy(result_string, temp);
			strcat(result_string, ": ");
			strcat(result_string, aux.name);
			strcat(result_string, "\n");
			    	
			print_code(result_string);
			
			id1.name = i;
			i = num_lin();
			
			strcpy(aux.name, i);
			strcat(aux.name, " := ");
			strcat(aux.name, id1.name);
			strcat(aux.name, " DIVF ");
  			strcat(aux.name, id2.name);
		}
		if (id1.val_type == FLOAT_TYPE && id2.val_type == INT_TYPE){
			aux.val_float =  id1.val_float / (float)id2.val_int;
			aux.val_type = FLOAT_TYPE;
			strcpy(aux.name, i);
			strcat(aux.name, " := ");
			strcat(aux.name, "I2F ");
			strcat(aux.name, id2.name);
			
			strcpy(result_string, "");
			sprintf(temp, "%i", varc3a.num);
			strcpy(result_string, temp);
			strcat(result_string, ": ");
			strcat(result_string, aux.name);
			strcat(result_string, "\n");
			    	
			print_code(result_string);
			
			id2.name = i;
			i = num_lin();
			
			strcpy(aux.name, i);
			strcat(aux.name, " := ");
			strcat(aux.name, id1.name);
			strcat(aux.name, " DIVF ");
  			strcat(aux.name, id2.name);
		}
		strcpy(result_string, "");
		sprintf(temp, "%i", varc3a.num);
		strcpy(result_string, temp);
		strcat(result_string, ": ");
		strcat(result_string, aux.name);
		strcat(result_string, "\n");
			    	
		print_code(result_string);
		aux.name = i;
	}
	
	return aux;
}

value_info mod_a(value_info id1, value_info id2){
	value_info aux;
	
	aux.hex_oct = id1.hex_oct;
	extern C3A varc3a;
	aux.name = malloc(100);
	char * i = num_lin();
	
	char *result_string = (char *)malloc(100 * sizeof(char)); // Asumiendo un tamaño suficientemente grande
    	strcpy(result_string, "");
    	char temp[50];
	
	if(id1.val_type == 1 || id2.val_type == 1){
		yylineno--;
		yyerror("Semantical error: value can be inicialized");
		aux.val_type = 1;
	}else{
		if (id1.val_type == STRING_TYPE || id2.val_type == STRING_TYPE){
			yylineno--;
			yyerror("Semantical error: Can not calculate modulus of literals of String type");
		}
		if (id1.val_type == BOOLEAN_TYPE || id2.val_type == BOOLEAN_TYPE) {
			yylineno--;
			yyerror("Semantical error: Can not calculate modulus of literals of Boolean type");
		}
		if (id2.val_type == INT_TYPE && id2.val_int == 0){
			yylineno--;
			yyerror("Semantical error: Can not be divided by 0");
		}
		if (id2.val_type == FLOAT_TYPE && id2.val_float == 0.0){
			yylineno--;
			yyerror("Semantical error: Can not be divided by 0.0");
		}
		if (id1.val_type == INT_TYPE && id2.val_type == INT_TYPE){
			aux.val_int = (int) mod_func((float)id1.val_int, id2.val_int);
			aux.val_type = INT_TYPE;
			
			strcpy(aux.name, i);
			strcat(aux.name, " := ");
			strcat(aux.name, id1.name);
			strcat(aux.name, " MODI ");
	  		strcat(aux.name, id2.name);
		}
		if (id1.val_type == FLOAT_TYPE && id2.val_type == FLOAT_TYPE){
			yylineno--;
			yyerror("Semantical error: Can not be divided by float");
		}
		if (id1.val_type == INT_TYPE && id2.val_type == FLOAT_TYPE){
			yylineno--;
			yyerror("Semantical error: Can not be divided by float");
		}
		if (id1.val_type == FLOAT_TYPE && id2.val_type == INT_TYPE){
			aux.val_float = mod_func(id1.val_float, id2.val_int);
			aux.val_type = FLOAT_TYPE;
			
			strcpy(aux.name, i);
			strcat(aux.name, " := ");
			strcat(aux.name, id1.name);
			strcat(aux.name, " MODF ");
	  		strcat(aux.name, id2.name);
		}
		strcpy(result_string, "");
		sprintf(temp, "%i", varc3a.num);
		strcpy(result_string, temp);
		strcat(result_string, ": ");
		strcat(result_string, aux.name);
		strcat(result_string, "\n");
			    	
		print_code(result_string);
		aux.name = i;
	}
	return aux;
}
float mod_func(float id1, int id2){
	if (id2 == 0){
		return 0.0;
	}
	float cociente = id1 / id2;
	float parteEntera = (int)cociente; 
	float resul = id1 - (parteEntera * id2);

	return resul;
}


value_info pow_a(value_info id1, value_info id2){
	value_info aux;
	
	aux.hex_oct = id1.hex_oct;
	extern C3A varc3a;
	aux.name = malloc(100);
	char * i = num_lin();
	char *result_string = (char *)malloc(100 * sizeof(char)); // Asumiendo un tamaño suficientemente grande
    	strcpy(result_string, "");
    	char temp[50];

	if(id1.val_type == 1 || id2.val_type == 1){
		yylineno--;
		yyerror("Semantical error: value can be inicialized");
		aux.val_type = 1;
	}else{

		if (id1.val_type == STRING_TYPE || id2.val_type == STRING_TYPE){
			yylineno--;
			yyerror("Semantical error: Can not calculate the power of String type");
		}
		if (id1.val_type == BOOLEAN_TYPE || id2.val_type == BOOLEAN_TYPE) {
			yylineno--;
			yyerror("Semantical error: Can not calculate the power of Boolean type");
		}
		if (id1.val_type == INT_TYPE && id2.val_type == INT_TYPE){
			id1.val_float = (float)id1.val_int;
			strcpy(aux.name, i);
			strcat(aux.name, " := ");
			strcat(aux.name, "I2F ");
			strcat(aux.name, id1.name);
			
			strcpy(result_string, "");
			sprintf(temp, "%i", varc3a.num);
			strcpy(result_string, temp);
			strcat(result_string, ": ");
			strcat(result_string, aux.name);
			strcat(result_string, "\n");
			    	
			print_code(result_string);
			
			id1.name = i;
			
			aux = pow_func(id1, id2);
			aux.val_type = FLOAT_TYPE;
			
		}
		if (id1.val_type == FLOAT_TYPE && id2.val_type == FLOAT_TYPE){
			yylineno--;
			yyerror("Semantical error: Can not be elevated by float");
		}
		if (id1.val_type == INT_TYPE && id2.val_type == FLOAT_TYPE){
			yylineno--;
			yyerror("Semantical error: Can not be elevated by float");
		}
		if (id1.val_type == FLOAT_TYPE && id2.val_type == INT_TYPE){
			aux =  pow_func(id1, id2);
			aux.val_type = FLOAT_TYPE;
			
		}
	}
	return aux;
}

value_info pow_func(value_info id1, value_info id2){
	value_info aux;
	aux.name = malloc(100);
	aux.val_float = id1.val_float;
	extern C3A varc3a;
	char * lin;
	char * num = malloc(20);
	char *result_string = (char *)malloc(100 * sizeof(char)); // Asumiendo un tamaño suficientemente grande
    	strcpy(result_string, "");
    	char temp[50];
	sprintf(num, "%f", id1.val_float);
	
    	if (id2.val_int >= 0){
        	for (int i = 1; i < id2.val_int; ++i){
         	   aux.val_float *= id1.val_float;
         	   lin = num_lin();
         	   strcpy(aux.name, lin);
		   strcat(aux.name, " := ");
		   strcat(aux.name, id1.name);
		   strcat(aux.name, " MULF ");
  		   strcat(aux.name, num);
  		   id1.name = lin;
  		
  		   strcpy(result_string, "");
		   sprintf(temp, "%i", varc3a.num);
		   strcpy(result_string, temp);
		   strcat(result_string, ": ");
		   strcat(result_string, aux.name);
		   strcat(result_string, "\n");
			    	
		   print_code(result_string);
        	}
    	} 
    	aux.name = lin;
    return aux;
}



int init_analisi_lexica(char *filename)
{
  int error;
  yyin = fopen(filename,"r");
  if(yyin == NULL) {
    error = EXIT_FAILURE;
  } else {
    error = EXIT_SUCCESS;
  }
  return error;
}


int end_analisi_lexica()
{
  int error;
  error = fclose(yyin);
  if (error == 0) {
    error = EXIT_SUCCESS;
  } else {
    error = EXIT_FAILURE;
  }
  return error;
}


int init_analisi_sintactica(char* filename)
{
  int error = EXIT_SUCCESS;
  yyout = fopen(filename,"w");
  if (yyout == NULL) {
    error = EXIT_FAILURE;
  }
  return error;
}


int end_analisi_sintactica(void)
{
  int error;

  error = fclose(yyout);

  if(error == 0) {
    error = EXIT_SUCCESS;
  } else {
    error = EXIT_FAILURE;
  }
  return error;
}


int analisi_semantica(void)
{
  int error;

  if (yyparse() == 0) {
    error =  EXIT_SUCCESS;
  } else {
    error =  EXIT_FAILURE;
  }
  return error;
}


void yyerror(char *explanation)
{
  fprintf(stderr, "Error: %s , in line %d\n", explanation, yylineno);
}
