1. Per compilar s'ha d'utilitzar la comanda make

2. Per executar el compilador s'ha d'utilitzar la seguent comanda: ./exe.exe <nom_ficher_codi> <nom_ficher_log>

3. El codi que es vol compilar s'ha de posar en un ficher txt i posar.ho com a segon parametre
